#JLL
from ruxit.api.base_plugin import RemoteBasePlugin
from ruxit.api.exceptions import AuthException, ConfigException
from collections import Counter
import requests
import requests.exceptions
import json
import logging
import os
import sys
import subprocess
from datetime import datetime
from datetime import timezone
import urllib3
import time


#################### Supported CustomPaylod
#"{ImpactedEntities}"
#"{ProblemDetailsJSONv2}"
#"{ProblemDetailsHTML}"
#"{ImpactedEntity}"
#"{ImpactedEntityNames}"
#"{PID}"
#"{ProblemID}"
#"{ProblemImpact}"
#"{ProblemSeverity}"
#"{ProblemTitle}"
#"{ProblemURL}"
#"{State}"
#"{Tags}"
#"{ProblemDetailsText}"
#"{Tags:[key]"

#################### NOT Supported CustomPaylod
#"{ProblemDetailsMarkdown}"
#"{ProblemDetailsJSON}"
 
##################################
## Variables don t modify
##################################
#Problem={'problemId': '', 'displayId': '', 'title': '', 'impactLevel': '', 'severityLevel': '','status': '', 'affectedEntities': '', 'impactedEntities': '', 'rootCauseEntity': '', 'managementZones': '', 'entityTags': '', 'problemFilters': '', 'startTime': '', 'endTime': '', 'evidenceDetails': '', 'recentComments': '', 'impactAnalysis': ''}
CustomPayloadTest={
    "tenant": "OPE-INTRA",
    "state": "OPEN",
    "problempid": "88888888888",
    "problemid": "888",
    "environment": "OPERATIONNEL",
    "problemimpact": "INFRASTRUCTURE",
    "origin": "dynmo.intra.renault.fr",
    "impactedentity": "Myhost1, Myservice1",
    "impactedentities": "Myhost1, Myservice1",
    "tags": "testtag1:testvalue, testtag2",
    "problemtitle": "Dynatrace problem notification test run for webhook",
    "problemdetailstext": "test alert details",
    "problemseverity": "PERFORMANCE",
    "alertingprofile": "test-profile"
}

OpenComment='the open ticket has been sent to the webhook'
ClosedComment='the closed ticket has been sent to the webhook'
ContextComment='webhook integration'
Result={'open':  0, 'closed':0, 'change': 0, 'success': 0, 'failed': 0}
pageSize='250'
delay='now-15m'

##################################
## API
##################################
APIproblem='/api/v2/problems'

##################################
## Others
##################################
logger = logging.getLogger(__name__)

#disable warning
urllib3.disable_warnings()

head = {
    'Accept': 'application/json',
    'Content-Type': 'application/json; charset=UTF-8'
}
##################################
## Class
##################################
class InternalWebhook(RemoteBasePlugin):
    
    def initialize(self, **kwargs):
        logger.info("Config: %s", self.config)

        if self.config["WebhookName"].strip() == '':
            logger.error("Error: [WebhookName] field cannot be empty")
            raise ConfigException("[WebhookName] field cannot be empty")
        
        if self.config["Tenant"].strip() == '':
            logger.error("Error: [Tenant] field cannot be empty")
            raise ConfigException("[Tenant] field cannot be empty")
        
        if self.config["Token"].strip() == '':
            logger.error("Error: [Token] field cannot be empty")      
            raise ConfigException("[Token] field cannot be empty")
        
        if self.config["AlertingProfile"].strip() == '':
            rlogger.error("[AlertingProfile] field cannot be empty")
            raise ConfigException("[AlertingProfile] field cannot be empty")

        if self.config["WebhookUrl"].strip() == '':
            logger.error("Error: [WebhookUrl] field cannot be empty")
            raise ConfigException("[WebhookUrl] field cannot be empty")
			
        if self.config["CustomPayload"].strip() == '':
            logger.error("[CustomPayload] field cannot be empty")
            raise ConfigException("[CustomPayload] field cannot be empty")

        self.Proxy = self.config["Proxy"]
        if self.Proxy:
            if self.config["base64creds"].strip() == '':
                logger.error("[base64creds] field cannot be empty")
                raise ConfigException("[base64creds] field cannot be empty")
                
            if self.config["proxyuser"].strip() == '':
                logger.error("[proxy_address] field cannot be empty")
                raise ConfigException("[proxy_address] field cannot be empty")

            if self.config["proxy_address"].strip() == '':
                logger.error("[proxy_address] field cannot be empty")
                raise ConfigException("[proxy_address] field cannot be empty")
            
            if self.config["proxy_port"].strip() == '':
                logger.error("[proxy_port] field cannot be empty")
                raise ConfigException("[proxy_port] field cannot be empty")
                
            if self.config["proxypass"].strip() == '':
                logger.error("[proxypass] field cannot be empty")
                raise ConfigException("[proxypass] field cannot be empty")
        
        self.WebhookName = self.config["WebhookName"]
        self.Tenant = self.config["Tenant"]
        self.Token = self.config["Token"]
        self.AlertingProfile = self.config["AlertingProfile"]
        self.WebhookUrl = self.config["WebhookUrl"]
        self.CustomPayload = json.loads(self.config["CustomPayload"])
        self.base64creds = self.config["base64creds"]
        self.proxyuser = self.config["proxyuser"]
        self.proxy_address = self.config["proxy_address"]
        self.proxy_port = self.config["proxy_port"]
        self.proxypass = self.config["proxypass"]

        self.Test = self.config["Test"]
        debugLogging = self.config["debug"]
        if debugLogging:
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.WARNING)

    def query(self, **kwargs):
        logger.info('query')

        if self.Test :
            logger.info('Info test : WebhookUrl', self.WebhookUrl, 'Proxy', self.Proxy, 'base64creds', self.base64creds, 'proxyuser', self.proxyuser, 'proxypass', self.proxypass, 'proxy_address', self.proxy_address, 'proxy_port', self.proxy_port)
            if self.Proxy:
                try :
                    postDynatraceAPIWebhook(self.WebhookUrl, CustomPayloadTest, self.base64creds, self.proxyuser, self.proxypass, self.proxy_address, self.proxy_port)
                except Exception as e:
                    logger.error('webhook connection error via proxy '+ self.WebhookUrl, e)
                    success=False
            else:
                try :
                    postDynatraceAPI(self.WebhookUrl, CustomPayloadTest)
                except Exception as e:
                    logger.error('webhook connection error '+ self.WebhookUrl, e)
                    success=False
            if 'success' !=False:
                logger.info('payload has been sent to webhook ', CustomPayloadTest)
    
        else:      
            #init variable
            ProblemIdOpen={}
            ProblemIdClose={}
            #Create topology
            group_name = 'webhook'
            group = self.topology_builder.create_group(group_name, group_name)
            device_name = self.WebhookName
            device = group.create_device(device_name, device_name)


            ProblemIdOpen=getproblem(self.Tenant, self.Token, self.AlertingProfile, 'open')
            ProblemIdClose=getproblem(self.Tenant, self.Token, self.AlertingProfile, 'closed')
            for problemid in ProblemIdOpen:
                postwebhook(self.Tenant, self.Token, problemid, 'open', self.WebhookUrl, self.CustomPayload, self.Proxy, self.base64creds, self.proxyuser, self.proxypass, self.proxy_address, self.proxy_port)
            for problemid in ProblemIdClose:
                postwebhook(self.Tenant, self.Token, problemid, 'closed', self.WebhookUrl, self.CustomPayload, self.Proxy, self.base64creds, self.proxyuser, self.proxypass, self.proxy_address, self.proxy_port)            

            Result['open']=len(ProblemIdOpen)
            Result['closed']=len(ProblemIdClose)
            print(Result)

            device.absolute(key='webhook.notification.success', value=Result['success'], dimensions={})
            device.absolute(key='webhook.notification.failed', value=Result['failed'], dimensions={})
            
            #init result
            Result['change']=0
            Result['success']=0
            Result['failed']=0

#Class for entity impacted
class Impacted_Entity:
    "entities impacted"
    def __init__(self,id,name,type,severity_already_count,entity_already_count):
        self.id=id
        self.name=name
        self.type=type
        self.severity_count=severity_already_count
        self.entity_count=entity_already_count

#Class for entity events
class Impacted_Entity_Severity:
    "entities impacted severity"
    def __init__(self,id,name,affected_entity,displayName,type):
        self.id=id
        self.name=name
        self.affected_entity=affected_entity
        self.displayName=displayName
        self.type=type
           
##################################
## Generic Dynatrace API
##################################

# generic function GET to call API with a given uri
def queryDynatraceAPI(uri):
    jsonContent = None
    response = requests.get(uri,headers=head,verify=False)
    # For successful API call, response code will be 200 (OK)
    if(response.ok):
        if(len(response.text) > 0):
            jsonContent = json.loads(response.text)
    else:
        jsonContent = json.loads(response.text)
        print(jsonContent)
        errorMessage = ""
        if(jsonContent["error"]):
            errorMessage = jsonContent["error"]["message"]
            print("Dynatrace API returned an error: " + errorMessage)
        jsonContent = None
        #raise Exception("Error", "Dynatrace API returned an error: " + errorMessage)

    return(jsonContent)


#generic function POST to call API with a given uri
def postDynatraceAPI(uri, payload):
    response = requests.post(uri,headers=head,verify=False, json=payload)
    print(response,response.text)
    logger.debug(response,response.text)
    return() 

def postDynatraceAPIWebhook(uri, payload, base64creds, proxyuser, proxypass, proxy_address, proxy_port):
    header_webhook = {
        'Content-Type': 'application/json',
        'Authorization': 'Basic ' + base64creds
    }
    proxyintra = 'http://' + proxyuser + ':' + proxypass + '@' + proxy_address + ':' + proxy_port
    proxies = {
        'http': proxyintra,
        'https': proxyintra
    }
    response = requests.post(uri,proxies=proxies,headers=header_webhook,verify=False, json=payload)
    logger.debug(response,response.text)
    return() 
   
##################################
## Get Problem ID
##################################
def getproblem(TENANT, TOKEN, alertingprofile, status):
    uri=TENANT+APIproblem+'?pageSize='+pageSize+'&from='+delay+'&problemSelector=problemFilterNames.equals('+alertingprofile+'),status('+status+')&Api-Token='+TOKEN
    ProblemId={}

    #print(uri)
    datastore = queryDynatraceAPI(uri)
    #print(datastore)
    problems = datastore['problems']
    for problem in problems :
        ProblemId[problem['problemId']]=problem['title']
        
    return(ProblemId)

   
##################################
## Test comment Problem ID
##################################
def postwebhook(TENANT, TOKEN, id, status, WebhookUrl, CustomPayload, Proxy, base64creds, proxyuser, proxypass, proxy_address, proxy_port):
    uri=TENANT+APIproblem+'/'+id+'/comments?Api-Token='+TOKEN
    
    #print(uri)
    datastore = queryDynatraceAPI(uri)
    #print(datastore)
    comments = datastore['comments']
    #print(comments)
    testopencomment=False
    testclosedcomment=False
    if comments != []:
        for comment in comments :
            if comment['content']==OpenComment :
                testopencomment=True
            if comment['content']==ClosedComment :
                testclosedcomment=True

    if (status == 'open' and not(testopencomment)) or (status == 'closed' and not(testclosedcomment) and (testopencomment)):
        Result['change']+=1
        try:
            generatewebhook(TENANT, TOKEN, id, status, WebhookUrl, CustomPayload, Proxy, base64creds, proxyuser, proxypass, proxy_address, proxy_port)
            #logger.info("Webhook for id {} was posted successfully.".format(id))
        except:
            logger.error("Error sending webhook for id {}".format(id))
            Result['failed']+=1
            return()        
        #print(Result)
        
    return()

##################################
## POST comment 
##################################
def postcomment(TENANT, TOKEN, id, status):
    uri=TENANT+APIproblem+'/'+id+'/comments?Api-Token='+TOKEN

    if status == 'open':
        payload={
              "message": OpenComment,
              "context": ContextComment
            }
        
    elif status == 'closed':
        payload={
              "message": ClosedComment,
              "context": ContextComment
            }
    
    #print(uri)
    result= postDynatraceAPI(uri,payload)
    #print("add comment ",id, status, result)
        
    return()

##################################
## Write text paylaod 
##################################
#for text format
def printtext(impat_level,count,impacted_entities_severity):
    printtext='\n'
    if impat_level != 'Environment':
        printtext=str(count)+' impacted '+impat_level
    else:
        printtext=str(count)+' impacted entities'
    for e in impacted_entities_severity:
        if e.impact_level == impat_level:
            if e.name != '':
                printtext=printtext+'\n\n'+e.type.lower().replace('_',' ')+'\n'+e.name
                if e.affected_entity != '':
                    printtext=printtext+'\n'+e.affected_entity
                printtext=printtext+'\n'
            entity_events=(e.__dict__)
            for i in entity_events:
                if i != 'id' and i != 'type' and i != 'impact_level' and i != 'affected_entity' and i != 'name' and entity_events[i] != '':
                    if i == 'displayName':
                        printtext=printtext+'\n'+str(entity_events[i])
                    else:
                        printtext=printtext+'\n '+str(entity_events[i])
    return(printtext)


##################################
## Write html paylaod 
##################################
#for html format
def printHTML(impat_level,count,impacted_entities_severity):
    printhtml='<br>'
    if impat_level != 'Environment':
        printhtml=str(count)+' impacted '+impat_level+'</b><hr><div>'
    else:
        printhtml=str(count)+' impacted entities'
    for e in impacted_entities_severity:
        if e.impact_level == impat_level:
            if e.name != '':
                printhtml=printhtml+'<br><div><span><br>'+e.type.lower().replace('_',' ')+'<span></span><br><b><span style=\"color:#7dc540; font-size:120%\">'+e.name+'</span></b>'
                if e.affected_entity != '':
                    printhtml=printhtml+'<br>'+e.affected_entity
                printhtml=printhtml+'<br>'
            entity_events=(e.__dict__)
            for i in entity_events:
                if i != 'id' and i != 'type' and i != 'impact_level' and i != 'affected_entity' and i != 'name' and entity_events[i] != '':
                    if i == 'displayName':
                        printhtml=printhtml+'<br>'+str(entity_events[i])
                    else:
                        printhtml=printhtml+'<br>'+str(entity_events[i])
    return(printhtml)

##################################
## Generate webhook 
##################################
def generatewebhook(TENANT, TOKEN, id, status, WebhookUrl, CustomPayload, Proxy, base64creds, proxyuser, proxypass, proxy_address, proxy_port):
    Payload={}
    uri=TENANT+APIproblem+'/'+id+'?Api-Token='+TOKEN
    Problem = queryDynatraceAPI(uri)
    #logger.info(print(Problem))
    #print(Problem)
    for key in CustomPayload :
       if CustomPayload[key] == '{ProblemID}':
            Payload[key] = Problem['displayId']
       elif CustomPayload[key] == '{PID}':
            Payload[key] = Problem['problemId']                
       elif CustomPayload[key] == '{ProblemTitle}':
            Payload[key] = Problem['title']
            
       elif CustomPayload[key] == '{ProblemImpact}':
            Payload[key] = Problem['impactLevel']
       elif CustomPayload[key] == '{ProblemSeverity}':
            Payload[key] = Problem['severityLevel']                
       elif CustomPayload[key] == '{State}':
            if Problem['status']=='OPEN':
                Payload[key] = 'OPEN'
            else:
                Payload[key] = 'RESOLVED'
                     
       elif str(CustomPayload[key]).startswith('{Tags'):
            if len(CustomPayload[key].split("[")) > 1:
                keyresult=''
                for tagkey in Problem['entityTags']:
                    if tagkey['key'] == CustomPayload[key].replace(']','[').split('[')[1] :
                            if keyresult != '':
                                keyresult=tagkey['stringRepresentation']+', '+keyresult
                            else:
                                keyresult=tagkey['stringRepresentation']
            else:
                keyresult=''
                for tagkey in Problem['entityTags']:
                            #print(Problem['entityTags'])
                            if keyresult != '':
                                keyresult=tagkey['stringRepresentation']+', '+keyresult
                            else:
                                keyresult=tagkey['stringRepresentation']
                        
            Payload[key] = keyresult
            '''
                        
       elif Payload[key] == '{Tags}':
            keyresult=''
            for tagkey in Problem['entityTags']:
                    if keyresult != '':
                        keyresult=tagkey['stringRepresentation']+', '+keyresult
                    else:
                        keyresult=tagkey['stringRepresentation']
                        
            Payload[key] = keyresult
            '''
                                
       elif CustomPayload[key] == '{ImpactedEntityNames}':
            entitylist=''
            for entity in Problem['affectedEntities']:
                if entitylist == '' :
                    entitylist=entity['name']
                else:
                    entitylist=entity['name']+', '+entitylist
            Payload[key] = entitylist
       elif CustomPayload[key] == '{ImpactedEntity}':
            evidencedetail=''
            for detail in Problem['evidenceDetails']['details']:
                if evidencedetail =='':
                    evidencedetail=detail['displayName']+' for '+detail['entity']['entityId']['type']+' '+detail['entity']['name']
                else:
                    evidencedetail=detail['displayName']+' for '+detail['entity']['entityId']['type']+' '+detail['entity']['name']+', '+evidencedetail
            Payload[key] = evidencedetail
       elif CustomPayload[key] == '{ImpactedEntities}':
            evidencedetaillist=[]
            for detail in Problem['evidenceDetails']['details']:
                evidencedetail={}
                evidencedetail['type']=detail['entity']['entityId']['type']
                evidencedetail['name']=detail['entity']['name']
                evidencedetail['entity']=detail['entity']['entityId']['id']
                evidencedetaillist.append(evidencedetail)        
            Payload[key] = str(evidencedetaillist)
            
       elif CustomPayload[key] == '{ProblemURL}':
            Payload[key] = TENANT+'/#problems/problemdetails;pid='+Problem['problemId']

       ###########
       elif CustomPayload[key] in ['{ProblemDetailsHTML}' , '{ProblemDetailsText}']:
            #start analyse problem from api problem for each problemID
            if Problem['status']=='OPEN':
                title='OPEN '+Problem['displayId']+' in environment'                    
                #date format
                pbdate ='Problem detected at: '+datetime.fromtimestamp(Problem['startTime']/1000, tz=timezone.utc).strftime('%H:%M')+' (UTC) '+ datetime.fromtimestamp(Problem['startTime']/1000).strftime('%d-%m-%y')
            else:
                title='RESOLVED'+' '+Problem['displayId']+' in environment'
                pbdate ='Problem detected at: '+datetime.fromtimestamp(Problem['startTime']/1000, tz=timezone.utc).strftime('%H:%M')+' (UTC) '+ datetime.fromtimestamp(Problem['startTime']/1000).strftime('%d-%m-%y')\
                +' - '+datetime.fromtimestamp(Problem['endTime']/1000, tz=timezone.utc).strftime('%H:%M')+' (UTC) '+ datetime.fromtimestamp(Problem['endTime']/1000).strftime('%d-%m-%y')   

            #get entitiID affected
            impacted_entities=[]
            impacted_entities_severity=[]
            n=0 #entity indice
            m=0 #entity severity indice
            count_application=0
            count_service=0
            count_infra=0
            count_environment=0

            #for entity impacted 
            for pb in Problem['affectedEntities']:
                impacted_entities.append(Impacted_Entity(pb['entityId']['id'],pb['name'],pb['entityId']['type'],False,False))

                #total impact analysis by entitiID
                affected_entity=''
                if 'impactAnalysis' in Problem:
                    if 'impacts' in Problem['impactAnalysis']:
                        k=0
                        while k < len(Problem['impactAnalysis']['impacts']):
                            if 'impactedEntity' in Problem['impactAnalysis']['impacts'][k]:
                                if impacted_entities[n].id == Problem['impactAnalysis']['impacts'][k]['impactedEntity']['entityId']['id']:
                                    if pb['entityId']['type'] == 'APPLICATION':
                                        if 'estimatedAffectedUsers' in Problem['impactAnalysis']['impacts'][k]:
                                            affected_entity='Total affected users: '+str(Problem['impactAnalysis']['impacts'][k]['estimatedAffectedUsers'])
                                    if pb['entityId']['type'] == 'SERVICE':
                                        if 'numberOfPotentiallyAffectedServiceCalls' in Problem['impactAnalysis']['impacts'][k]:
                                             affected_entity='Total affected service calls: '+str(Problem['impactAnalysis']['impacts'][k]['numberOfPotentiallyAffectedServiceCalls'])
                                         
                            k+=1

                #list of details       
                if 'evidenceDetails' in Problem:
                    if 'details' in Problem['evidenceDetails']:
                        for i in Problem['evidenceDetails']['details']:
                            #print(i)
                            if i['evidenceType'] == 'EVENT' :
                                if impacted_entities[n].id == i['entity']['entityId']['id'] :
                                    if not(impacted_entities[n].entity_count):
                                        impacted_entities_severity.append(Impacted_Entity_Severity(i['entity']['entityId']['id'],i['entity']['name'],affected_entity,i['displayName'],pb['entityId']['type']))  
                                        impacted_entities[n].entity_count=True
                                    else:
                                        impacted_entities_severity.append(Impacted_Entity_Severity(i['entity']['entityId']['id'],'','',i['displayName'],pb['entityId']['type']))  
                                        
                                    is_response_time_p50_abnormal=False
                                    is_response_time_p90_abnormal=False
                                    is_response_time_threshold=False
                                    metric=False
                                    impact_level_exist=False
                                    affected_load=''
                                    response_time_p50=''
                                    response_time_p90=''
                                    response_time_p50_reference=''
                                    response_time_p90_reference=''
                                    metric_description=''
                                    event_description=''
                                    event_severity=''
                                    failure_rate=''
                                    for properties in i['data']['properties']:
                                        if properties['key'] == 'dt.event.impact_level':
                                            event_severity=properties['value']
                                            impacted_entities_severity[m].impact_level=event_severity
                                            if not(impacted_entities[n].severity_count): 
                                                if properties['value'] == 'Application':
                                                    count_application+=1
                                                elif properties['value'] == 'Services':
                                                    count_service+=1
                                                elif properties['value'] == 'Infrastructure':
                                                    count_infra+=1
                                                else:
                                                    count_environment+=1
                                                impact_level_exist=True
                                                impacted_entities[n].severity_count=True
                                        
                                        ##mapping value with  evidenceDetails
                                        #service & application: get the unexpected load informations
                                        #service & application: get the affected load
                                        if properties['key'] == 'dt.event.baseline.affected_load':
                                            affected_load=str(round(float(properties['value']),2))+' /min'
                                        elif properties['key'] == 'dt.event.baseline.affected_load_reference':
                                            affected_load_baseline=str(round(float(properties['value']),2))+' /min'
                                        #service & application: get the performance                                
                                        elif properties['key'] == 'dt.event.baseline.is_response_time_p50_abnormal':
                                            if properties['value'] == 'true':
                                                is_response_time_p50_abnormal=True
                                        elif properties['key'] == 'dt.event.baseline.is_response_time_p90_abnormal':
                                            if properties['value'] == 'true':
                                                is_response_time_p90_abnormal=True
                                        elif properties['key'] == 'dt.event.baseline.response_time_p50':
                                            response_time_p50=round(float(properties['value'])/1000000,2)
                                        elif properties['key'] == 'dt.event.baseline.response_time_p90':
                                            response_time_p90=round(float(properties['value'])/1000000,2)
                                        elif properties['key'] == 'dt.event.baseline.response_time_p50_reference':
                                            response_time_p50_reference=round(float(properties['value'])/1000000,2)
                                        elif properties['key'] == 'dt.event.baseline.response_time_p90_reference':
                                            response_time_p90_reference=round(float(properties['value'])/1000000,2)
                                        #threshlod or baseline 
                                        elif properties['key'] == 'dt.event.baseline.static_user_override':
                                            if properties['value'] == 'true':
                                                is_response_time_threshold=True
                                        #service: get the request name                                
                                        elif properties['key'] == 'dt.event.baseline.service_method':
                                            if 'SERVICE_METHOD_GROUP'in properties['value']:
                                                entityType='SERVICE_METHOD_GROUP'
                                            elif 'SERVICE_METHOD' in properties['value']:
                                                entityType='SERVICE_METHOD'
                                            if entityType in [ 'SERVICE_METHOD_GROUP', 'SERVICE_METHOD']:
                                                uri=TENANT+'/api/v2/entities?entitySelector=type('+entityType+'),entityId('+properties['value']+')&Api-Token='+TOKEN
                                                #print(uri)
                                                datastore=queryDynatraceAPI(uri)
                                            if type(datastore) != type(None):
                                                if 'entities' in datastore:
                                                    if datastore['totalCount'] > 0:
                                                        impacted_entities_severity[m].Service_method='Request: '+datastore['entities'][0]['displayName']                                            
                                        #service & application: get the failure rate                                
                                        elif properties['key'] == 'dt.event.baseline.error_rate':
                                            failure_rate=str(round(float(properties['value'])*100,2))+'%'
                                        elif properties['key'] == 'dt.event.baseline.error_rate_reference':
                                            failure_rate_reference=str(round(float(properties['value'])*100,2))+'%'
                                        #Synthetic: 
                                        elif properties['key'] == 'dt.event.synthetic_affected_locations':
                                            location=properties['value'].replace('{','').replace('}','').split('=')
                                            if len(location) > 0:
                                                impacted_entities_severity[m].affected_location='Affected location '+location[0]
                                        elif properties['key'] == 'dt.event.synthetic_status_codes_and_messages':
                                            impacted_entities_severity[m].satus_code='Status code '+properties['value'].replace('{','').replace('}','').replace('=','')
                                        elif properties['key'] == 'dt.event.synthetic_affected_events':
                                            synthetic_events=properties['value'].split('"')
                                            if len(synthetic_events) > 1:
                                                impacted_entities_severity[m].satus_code='Synthetic events '+synthetic_events[1]
                                        #infra:
                                        elif properties['key'] == 'dt.event.metric_selector':
                                            #get the disk name
                                            for i in  properties['value'].replace(')','').split(','): 
                                                if 'DISK' in i:
                                                    uri=TENANT+'/api/v2/entities?entitySelector=type(DISK),entityId('+i+')&Api-Token='+TOKEN
                                                    datastore=queryDynatraceAPI(uri)
                                                    if type(datastore) != type(None):
                                                        if 'entities' in datastore:
                                                            if datastore['totalCount'] > 0:
                                                                impacted_entities_severity[m].disk='Disk: '+datastore['entities'][0]['displayName']
                                            #get the description and metric name 
                                            uri=TENANT+'/api/v2/metrics?metricSelector=('+properties['value']+')&Api-Token='+TOKEN
                                            datastore=queryDynatraceAPI(uri)
                                            if type(datastore) != type(None):
                                                if 'totalCount' in datastore:
                                                    if datastore['totalCount'] > 0:
                                                        if 'description' in datastore['metrics'][0]:
                                                            metric_description=datastore['metrics'][0]['description']
                                                            if metric_description != '':
                                                                impacted_entities_severity[m].metric_description='Metric description: '+metric_description                                        
                                                            else:
                                                                description=datastore['metrics'][0]['displayName']
                                                                if metric_description != '':
                                                                    impacted_entities_severity[m].metric_description='Metric name: '+metric_description                                        
                                        #infra: get the threshold                
                                        elif properties['key'] == 'dt.event.metric_threshold':
                                            if 'threshold' not in metric_description and 'threshold' not in event_description:
                                                impacted_entities_severity[m].metric_threshold='Metric threshold: ' +properties['value']
                                        #infra: get the CPU info
                                        elif properties['key'] == 'dt.event.oa.cpu_idle_value':
                                            metric=True
                                            impacted_entities_severity[m].cpu_idle_value='CPU usage value: ' +str(round(100-float(properties['value']),2))+'%'
                                        elif properties['key'] == 'dt.event.oa.cpu_idle_threshold':
                                            impacted_entities_severity[m].cpu_idle_value_threshold='CPU usage threshold: ' +str(round(100-float(properties['value'])*100,2))+'%'
                                        #infra: get the Memory info
                                        elif properties['key'] == 'dt.event.oa.mem_percentage_available':
                                            metric=True
                                            impacted_entities_severity[m].mem_available='Memory available:' +str(round(float(properties['value']),2))+'%'
                                        elif properties['key'] == 'dt.event.oa.mem_percentage_available_threshold':
                                            impacted_entities_severity[m].mem_threshold='Memory available threshold: ' +str(round(float(properties['value'])*100,2))+'%'
                                        elif properties['key'] == 'dt.event.oa.mem_pagefaults':
                                            impacted_entities_severity[m].mem_pagefaults='Pagefaults: ' +str(round(float(properties['value']),2))
                                        elif properties['key'] == 'dt.event.oa.mem_pagefaults_threshold':
                                            impacted_entities_severity[m].pagefaults_threshold='Pagefaults threshold: ' +str(round(float(properties['value']),2))
                                        #custom: get the metric events einfo
                                        elif properties['key'] == 'dt.event.description':
                                            event_description='Event description: '+properties['value']
                                            impacted_entities_severity[m].event_description=event_description
                                        #continue here           
                                        # 
                                        ##end elif
                                    ##Performance Service and Application - with threshold
                                    if is_response_time_threshold:
                                        if is_response_time_p50_abnormal :
                                            impacted_entities_severity[m].current_response_time='The current response time ('+str(round(response_time_p50,2))+' s) exceeds your customer threshold'
                                        if not(is_response_time_p50_abnormal) and is_response_time_p90_abnormal:
                                            impacted_entities_severity[m].slowest_response_time='The current response time ('+str(round(response_time_p90,2))+' s) within the slowest 10% exceeds your customer threshold'                                    
                                        if failure_rate != '':
                                            impacted_entities_severity[m].error_rate='Failure rate '+failure_rate+' exceeds your customer threshold'
                                    ##Performance Service and Application - with baseline
                                    else:
                                        if is_response_time_p50_abnormal :
                                            if response_time_p50_reference > 0:
                                                percentage=round((response_time_p50-response_time_p50_reference)/response_time_p50_reference*100,2)
                                                impacted_entities_severity[m].current_response_time='The current response time ('+str(round(response_time_p50,2))+' s) exceeds the baseline ('+str(response_time_p50_reference)+') s by '+str(percentage)+' %'
                                            else:
                                                impacted_entities_severity[m].current_response_time='The current response time ('+str(round(response_time_p50,2))+' s) exceeds the baseline'

                                        if not(is_response_time_p50_abnormal) and is_response_time_p90_abnormal:
                                            if response_time_p90_reference > 0:
                                                percentage=round((response_time_p90-response_time_p90_reference)/response_time_p90_reference*100,2)
                                                impacted_entities_severity[m].slowest_response_time='The slowest response time ('+str(round(response_time_p90,2))+' s) exceeds the baseline ('+str(response_time_p90_reference)+') s by '+str(percentage)+' %'
                                            else:
                                                impacted_entities_severity[m].slowest_response_time='The current response time ('+str(round(response_time_p90,2))+' s) exceeds the baseline'
                                        if failure_rate != '':
                                            impacted_entities_severity[m].error_rate='Failure rate '+failure_rate+' exceeds the baseline '+failure_rate_reference 
                                    ##identification host for process group instances, pod instance and namespace instance
                                    if event_severity == 'Infrastructure':
                                        #Get host name from process
                                        if impacted_entities_severity[m].type=='PROCESS_GROUP_INSTANCE':
                                            uri=TENANT+'/api/v2/entities?entitySelector=type(HOST),toRelationships.isProcessOf(type(PROCESS_GROUP_INSTANCE),entityId('+impacted_entities_severity[m].id+'))&Api-Token='+TOKEN
                                            #print(uri)
                                            datastore=queryDynatraceAPI(uri)
                                            if type(datastore) != type(None):
                                                if 'entities' in datastore:
                                                    if datastore['totalCount'] > 0:
                                                        impacted_entities_severity[m].run_on_host='On host: '+datastore['entities'][0]['displayName']
                                        #Get kube name from namespace
                                        if impacted_entities_severity[m].type=='CLOUD_APPLICATION_NAMESPACE':
                                            uri=TENANT+'/api/v2/entities?entitySelector=type(KUBERNETES_NODE),fromRelationships.isClusterOfNamespace(type(CLOUD_APPLICATION_NAMESPACE),entityId('+impacted_entities_severity[m].id+'))&Api-Token='+TOKEN
                                            #print(uri)
                                            datastore=queryDynatraceAPI(uri)
                                            if type(datastore) != type(None):                                    
                                                if 'entities' in datastore:
                                                    if datastore['totalCount'] > 0:
                                                        impacted_entities_severity[m].kube_name='Kube name: '+datastore['entities'][0]['displayName']
                                        #Get namespace and kube name from workload
                                        if impacted_entities_severity[m].type=='CLOUD_APPLICATION':
                                            uri=TENANT+'/api/v2/entities?entitySelector=type(KUBERNETES_CLUSTER),fromRelationships.isClusterOfCa(type(CLOUD_APPLICATION),entityId('+impacted_entities_severity[m].id+'))&Api-Token='+TOKEN
                                            #print(uri)
                                            datastore=queryDynatraceAPI(uri)
                                            if type(datastore) != type(None):
                                                if 'entities' in datastore:
                                                    if datastore['totalCount'] > 0:
                                                        impacted_entities_severity[m].kube_name='Kube name: '+datastore['entities'][0]['displayName']
                                            uri=TENANT+'/api/v2/entities?entitySelector=type(CLOUD_APPLICATION_NAMESPACE),fromRelationships.isNamespaceOfCai(type(CLOUD_APPLICATION_INSTANCE),entityId('+impacted_entities_severity[m].id+'))&Api-Token='+TOKEN
                                            #print(uri)
                                            datastore=queryDynatraceAPI(uri)
                                            if type(datastore) != type(None):
                                                if 'entities' in datastore:
                                                    if datastore['totalCount'] > 0:
                                                        impacted_entities_severity[m].namespace='Namespace: '+datastore['entities'][0]['displayName']
                                        #Get workload, namespace and kube name from pod
                                        if impacted_entities_severity[m].type=='CLOUD_APPLICATION_INSTANCE':
                                            uri=TENANT+'/api/v2/entities?entitySelector=type(KUBERNETES_CLUSTER),fromRelationships.isClusterOfCai(type(CLOUD_APPLICATION_INSTANCE),entityId('+impacted_entities_severity[m].id+'))&Api-Token='+TOKEN
                                            #print(uri)
                                            datastore=queryDynatraceAPI(uri)
                                            if type(datastore) != type(None):
                                                if 'entities' in datastore:
                                                    if datastore['totalCount'] > 0:
                                                        impacted_entities_severity[m].kube_name='Kube name: '+datastore['entities'][0]['displayName']
                                            uri=TENANT+'/api/v2/entities?entitySelector=type(CLOUD_APPLICATION_NAMESPACE),fromRelationships.isNamespaceOfCai(type(CLOUD_APPLICATION_INSTANCE),entityId('+impacted_entities_severity[m].id+'))&Api-Token='+TOKEN
                                            #print(uri)
                                            datastore=queryDynatraceAPI(uri)
                                            if type(datastore) != type(None):
                                                if 'entities' in datastore:
                                                    if datastore['totalCount'] > 0:
                                                        impacted_entities_severity[m].namespace='Namespace: '+datastore['entities'][0]['displayName']
                                            uri=TENANT+'/api/v2/entities?entitySelector=type(CLOUD_APPLICATION),toRelationships.isInstanceOf(type(CLOUD_APPLICATION_INSTANCE),entityId('+impacted_entities_severity[m].id+'))&Api-Token='+TOKEN
                                            #print(uri)
                                            datastore=queryDynatraceAPI(uri)
                                            if type(datastore) != type(None):
                                                if 'entities' in datastore:
                                                    if datastore['totalCount'] > 0:
                                                        impacted_entities_severity[m].workload='Workload: '+datastore['entities'][0]['displayName']
                                        #rename with process, namespace, workload and pod   
                                        if impacted_entities_severity[m].type in ['PROCESS_GROUP_INSTANCE', 'CLOUD_APPLICATION_NAMESPACE', 'CLOUD_APPLICATION', 'CLOUD_APPLICATION_INSTANCE']:
                                            if impacted_entities_severity[m].type=='CLOUD_APPLICATION_NAMESPACE':
                                                impacted_entities_severity[m].type='Namespace'
                                            if impacted_entities_severity[m].type=='CLOUD_APPLICATION':
                                                impacted_entities_severity[m].type='Workload'
                                            if impacted_entities_severity[m].type=='CLOUD_APPLICATION_INSTANCE':
                                                impacted_entities_severity[m].type='Pod'
                                            if impacted_entities_severity[m].type=='PROCESS_GROUP_INSTANCE':
                                                impacted_entities_severity[m].type='Process'
                                        #value before and after from the evidenceDetails/METRIC
                                        if not metric :
                                            for p in Problem['evidenceDetails']['details']:
                                                if p['evidenceType'] == 'METRIC' :
                                                    if impacted_entities[n].id == p['entity']['entityId']['id'] :
                                                        if 'valueBeforeChangePoint' in p:
                                                            impacted_entities_severity[m].valuebefore='Value before change: '+str(round(float(p['valueBeforeChangePoint']),2))
                                                        if 'valueBeforeChangePoint' in p:
                                                            impacted_entities_severity[m].valueafter='Value after change: '+str(round(float(p['valueAfterChangePoint']),2))
                                                        if 'unit' in p:
                                                            impacted_entities_severity[m].unit='Unit: '+p['unit'].lower()
                                            
                                    #affected load at least of the event object       
                                    if affected_load !='' :
                                        if impacted_entities_severity[m].type=='SERVICE':
                                            if impacted_entities_severity[m].displayName=='Unexpected low load' :
                                                impacted_entities_severity[m].affected_load='Current requests: '+affected_load
                                                impacted_entities_severity[m].affected_load_baseline='Expected requests (baseline): '+affected_load_baseline
                                            else:
                                                impacted_entities_severity[m].affected_load='Affected requests: '+affected_load
                                        if impacted_entities_severity[m].type=='APPLICATION' :
                                            if impacted_entities_severity[m].displayName=='Unexpected low load' :
                                                impacted_entities_severity[m].affected_load='Current user actions: '+affected_load
                                                impacted_entities_severity[m].affected_load_baseline='Expected user actions (baseline): '+affected_load_baseline
                                            else:
                                                impacted_entities_severity[m].affected_load='Affected user actions: '+affected_load
                                    #end loop severity
                                    m+=1               
                #end loop entity problems
                n+=1
            #header, title date commun of html and text
            if Problem['status']=='OPEN':
                    title='OPEN Problem'+Problem['displayId']+' in environment'                  
                    #date format
                    pbdate ='Problem detected at: '+datetime.fromtimestamp(Problem['startTime']/1000, tz=timezone.utc).strftime('%H:%M')+' (UTC) '+datetime.fromtimestamp(Problem['startTime']/1000).strftime('%d-%m-%y')
            else:
                    title='RESOLVED Problem'+' '+Problem['displayId']+' in environment'
                    pbdate ='Problem detected at: '+datetime.fromtimestamp(Problem['startTime']/1000, tz=timezone.utc).strftime('%H:%M')+' (UTC) '+datetime.fromtimestamp(Problem['startTime']/1000).strftime('%d-%m-%y')\
                                     +' - '+datetime.fromtimestamp(Problem['endTime']/1000, tz=timezone.utc).strftime('%H:%M')+' (UTC) '+ datetime.fromtimestamp(Problem['endTime']/1000).strftime('%d-%m-%y')   
            #####Display ProblemDetailsText
            if CustomPayload[key] == '{ProblemDetailsText}':
                ProblemDetailsTextresult=title+' '+TENANT.replace('/','.').split('.')[2]+'\n'
                ProblemDetailsTextresult=ProblemDetailsTextresult+pbdate
                #display application                   
                if count_application > 0:
                    ProblemDetailsTextresult=ProblemDetailsTextresult+'\n\n'+printtext('Application',count_application,impacted_entities_severity)
                #display service                   
                if count_service > 0:
                    ProblemDetailsTextresult=ProblemDetailsTextresult+'\n\n'+printtext('Services',count_service,impacted_entities_severity)
                #display infra    
                if count_infra > 0:           
                    ProblemDetailsTextresult=ProblemDetailsTextresult+'\n\n'+printtext('Infrastructure',count_infra,impacted_entities_severity)
                #display environment    
                if count_environment > 0:           
                    ProblemDetailsTextresult=ProblemDetailsTextresult+'\n\n'+printtext('Environment',count_environment,impacted_entities_severity)

                Payload[key] = ProblemDetailsTextresult

            #####Display ProblemDetailsHTML
            if CustomPayload[key] == '{ProblemDetailsHTML}':
                ProblemDetailsHTMLresult='<h3>'+title+'<i> '+TENANT.replace('/','.').split('.')[2]+'</i></h3><br><small>'+pbdate+'</small><hr><b>'
                #display application                   
                if count_application > 0:
                    ProblemDetailsHTMLresult=ProblemDetailsHTMLresult+'<br>'+printHTML('Application',count_application,impacted_entities_severity)
                #display service                   
                if count_service > 0:
                    ProblemDetailsHTMLresult=ProblemDetailsHTMLresult+'<br>'+printHTML('Services',count_service,impacted_entities_severity)
                #display infra    
                if count_infra > 0:           
                    ProblemDetailsHTMLresult=ProblemDetailsHTMLresult+'<br>'+printHTML('Infrastructure',count_infra,impacted_entities_severity)
                #display environment    
                if count_environment > 0:           
                    ProblemDetailsHTMLresult=ProblemDetailsHTMLresult+'<br>'+printHTML('Environment',count_environment,impacted_entities_severity)
                #get the link to the dashboard
                ProblemDetailsHTMLresult=ProblemDetailsHTMLresult+'</p></div><hr><p><a target=\"_blank\" href=\"'+TENANT+'/#problems/problemdetails;pid='+Problem['problemId']+'\">Open in Browser</a></p>'
                Payload[key] = ProblemDetailsHTMLresult

       ###########
    #print(WebhookUrl)
    success=True
    if Proxy:
        try :
            postDynatraceAPIWebhook(WebhookUrl, Payload, base64creds, proxyuser, proxypass, proxy_address, proxy_port)
        except Exception as e:
           logger.error('webhook connection error via proxy'+ self.WebhookUrl, e)
           success=False
    else:
        try :
            postDynatraceAPI(WebhookUrl, Payload)
        except Exception as e:
           logger.error('webhook connection error '+ self.WebhookUrl, e)
           success=False

    if success:
        postcomment(TENANT, TOKEN, id, status)
        Result['success']+=1
    else:
        Result['failed']+=1
        


###########
